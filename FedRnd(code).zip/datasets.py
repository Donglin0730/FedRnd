import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, datasets, utils
import torchvision.models.resnet

def data_loading(args):

    if args.dataset == 'mnist':
        transforms_mnist = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))
        ])
        trainset = datasets.MNIST('../data/mnist/', train=True, download=True, transform=transforms_mnist)
        testset = datasets.MNIST('../data/mnist/', train=False, download=True, transform=transforms_mnist)
        input_channel = 1

    elif args.dataset == 'fashionmnist':
        trans = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))
        ])
        trainset = datasets.FashionMNIST('../data/fashionmnist/', train=True, download=True, transform=trans)
        testset = datasets.FashionMNIST('../data/fashionmnist/', train=False, download=True, transform=trans)
        input_channel = 1

    elif args.dataset == 'cifar10':
        trans_train = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_val = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trainset = datasets.CIFAR10('../data/cifar10/', train=True, download=True, transform=trans_train)
        testset = datasets.CIFAR10('../data/cifar10/', train=False, download=True, transform=trans_val)
        input_channel = 3

    elif args.dataset == 'cifar100':
        trans_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.507, 0.487, 0.441], std=[0.267, 0.256, 0.276])
        ])
        trans_val = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.507, 0.487, 0.441], std=[0.267, 0.256, 0.276])
        ])
        trainset = datasets.CIFAR100('../data/cifar100/', train=True, download=True, transform=trans_train)
        testset = datasets.CIFAR100('../data/cifar100/', train=False, download=True, transform=trans_val)
        input_channel = 3
    elif args.dataset == 'tinyimagenet':
        trans_train = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.RandomCrop(64, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_val = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trainset = datasets.ImageFolder('../data/tinyimagenet/train', transform=trans_train)
        testset = datasets.ImageFolder('../data/tinyimagenet/val', transform=trans_val)
        input_channel = 3

    elif args.dataset == 'animal10':
        trans_train = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.RandomCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_val = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trainset = datasets.ImageFolder('../data/animal10/train_dataset', transform=trans_train)
        testset = datasets.ImageFolder('../data/animal10/val_dataset', transform=trans_val)
        input_channel = 3

    elif args.dataset == 'ImageNet':
        train_transforms = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.RandomCrop(64),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        val_transforms = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trainset = datasets.ImageFolder(root='-', transform=train_transforms)
        testset = datasets.ImageFolder(root='-', transform=val_transforms)
        input_channel = 3

    else:
        raise NotImplementedError('Error: unrecognized dataset')

    return trainset, testset

import os
from collections import OrderedDict
import copy
import numpy as np
import random
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader, Subset
import options

def set_random_seed(seed):
    """6 is my favorite number."""
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)

def sample_by_class(targets, num_class, a, b):
    class_idcs = [[] for i in range(num_class)]
    for j in range(a, b):
        class_idcs[targets[j]].append(j)
    return class_idcs

def data_noisifying(args, targets, num_data):
    gamma_s = np.random.binomial(1, args.noise_ratio, args.num_worker)
    gamma_c_initial = np.random.rand(args.num_worker)
    gamma_c_initial = gamma_c_initial * (1.0 - args.noise_lowbound) + args.noise_lowbound
    gamma_c = gamma_s * gamma_c_initial
    noisy_targets = copy.deepcopy(targets)
    real_noise_level = [0.00 for i in range(args.num_worker)]

    for k in np.where(gamma_c > 0)[0]:
        ture_targets = np.array(noisy_targets[k])
        prob = np.random.rand(len(ture_targets))
        noisy_idx = np.where(prob <= gamma_c[k])[0]
        for idx in noisy_idx:
            ture_targets[idx] = noisify_label(ture_targets[idx], args.num_class, args.noise_type)
        noisy_targets[k] = ture_targets

        noise_count = 0
        for idx in range(len(ture_targets)):
            if noisy_targets[k][idx] != targets[k][idx]:
                noise_count = noise_count + 1
        noise_level = round(noise_count / num_data[k], 2) if num_data[k] != 0 else 0.00
        real_noise_level[k] = noise_level

    return noisy_targets, real_noise_level

def noisify_label(true_label, num_classes=10, noise_type="symmetric"):
    if noise_type == "symmetric":
        label_lst = list(range(num_classes))
        label_lst.remove(true_label)
        return random.sample(label_lst, k=1)[0]

    elif noise_type == "pairflip":
        return (true_label - 1) % num_classes

def iid_sampling(class_idcs, num_workers, seed):
    np.random.seed(seed)
    client_idcs = [[] for _ in range(num_workers)]

    for class_index in range(len(class_idcs)):
        class_length = len(class_idcs[class_index])
        class_random_idcs = np.random.permutation(class_length)
        client_class_idcs = np.array_split(class_random_idcs, num_workers)

        for worker_index in range(num_workers):
            client_class = np.array(class_idcs[class_index])[client_class_idcs[worker_index]]
            client_idcs[worker_index] = np.concatenate((client_idcs[worker_index], client_class)).astype(np.int32)

    return client_idcs

def n_iid_sampling(class_idcs, n_train, num_workers, seed):
    client_idcs = [np.array([]) for i in range(num_workers)]
    local_datasize = int(n_train / num_workers)
    np.random.seed(seed)
    classes_per_client = 5
    Num_classes = 10
    labels_array = [i for i in range(Num_classes)]

    for i in range(num_workers):
        selected_labels = np.random.choice(labels_array, classes_per_client, replace=False)
        client_distribution = np.array([0. for j in labels_array])

        for each in selected_labels:
            client_distribution[each] = random.uniform(0, 1)
        client_distribution /= client_distribution.sum()
        Bias_array = client_distribution
        Bias_num_array = copy.deepcopy(client_distribution)

        for k in range(len(client_distribution)):
            Bias_num_array[k] = int(local_datasize * Bias_array[k])
            client_idcs[i] = np.concatenate((client_idcs[i], np.random.choice(class_idcs[k], int(Bias_num_array[k]))),
                                            axis=0)
    for i in range(len(client_idcs)):
        client_idcs[i] = client_idcs[i].astype(np.int32)

    return client_idcs

def noniid_sampling(train_labels, alpha, n_clients, seed):
    '''
    Dirichlet distribution
    '''
    np.random.seed(seed)
    n_classes = train_labels.max() + 1
    label_distribution = np.random.dirichlet([alpha] * n_clients, n_classes)
    class_idcs = [np.argwhere(train_labels == y).flatten() for y in range(n_classes)]
    client_idcs = [[] for _ in range(n_clients)]

    for c, fracs in zip(class_idcs, label_distribution):
        for i, idcs in enumerate(np.split(c, (np.cumsum(fracs)[:-1] * len(c)).astype(int))):
            client_idcs[i] += [idcs]

    client_idcs = [np.concatenate(idcs) for idcs in client_idcs]
    return client_idcs

def Clothing_sampling(n_train, num_workers):
    all_idxs=np.array([i for i in range(n_train)]) # initial user and index for whole dataset
    random_idcs = np.random.choice(n_train, n_train, replace=False)# 'replace=False' make sure that there is no repeat
    idcs_permuted = all_idxs[random_idcs]
    client_idcs = np.split(idcs_permuted, num_workers)
    return client_idcs

def random_sampling(class_idcs, num_workers, seed):
    np.random.seed(seed)
    client_idcs = [[] for _ in range(num_workers)]

    for class_samples in class_idcs:
        num_samples = len(class_samples)
        if num_samples >= num_workers:
            np.random.shuffle(class_samples)
            for i in range(num_workers):
                client_idcs[i].append(class_samples[i])
            for i in range(num_workers, num_samples):
                client_idcs[i % num_workers].append(class_samples[i])
        else:
            selected_samples = np.random.choice(class_samples, size=num_samples, replace=False)
            random_clients = np.random.choice(num_workers, size=num_samples, replace=False)
            for i in range(num_samples):
                client_idcs[random_clients[i]].append(selected_samples[i])

    for worker_index in range(num_workers):
        client_idcs[worker_index] = np.array(client_idcs[worker_index], dtype=np.int32)

    return client_idcs

def trainset_split(targets, data, client_idcs, num_worker):
    client_data = [[] for i in range(num_worker)]
    for i in range(num_worker):
        client_data[i] = [data[idx] for idx in client_idcs[i]]
    client_targets = [np.array(targets)[client_idcs[i]] for i in range(num_worker)]
    num_client_data = []
    for i in range(len(client_data)):
        num_client_data.append(len(client_data[i]))

    return client_data, client_targets, num_client_data

def FedAvg(selected, weights, model_dict, update_dict):
    weighted_update = dict()
    for name, data in model_dict.items():
        weighted_update[name] = torch.zeros_like(data).float()
    for name, data in model_dict.items():
        for i in range(len(update_dict)):
            weighted_update[name] += update_dict[str(selected[i])][name] * weights[i]
        model_dict[name] = data + weighted_update[name]
    return model_dict




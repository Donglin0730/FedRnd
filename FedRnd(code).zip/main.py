import gc
import copy
import numpy as np
import torch
import loss_func
import models
from client import Clients
from verify import validate
from datasets import data_loading
from options import args_parser
from torch.utils.data import DataLoader, random_split
from utils import (trainset_split, iid_sampling, set_random_seed, data_noisifying,
                   sample_by_class, n_iid_sampling, Clothing_sampling, random_sampling, FedAvg)


def main(args):
    device = torch.device('cuda:0')
    torch.cuda.empty_cache()
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

    # Data initialization
    trainset, testset = data_loading(args)
    testloader = DataLoader(testset, batch_size=args.B, shuffle=True, num_workers=4)
    # Split the training set into two parts: 20% as initial data, 80% as dynamically added data
    original_size = int(0.2 * len(trainset))  # Calculate the size of the initial dataset
    extra_size = len(trainset) - original_size  # Calculate the size of the extra dataset
    # Use random split to divide the training set into two subsets
    original_set, extra_set = random_split(trainset, [original_size, extra_size])

    # Extract true indices of original_set (handling index mapping after random_split)
    original_indices = original_set.indices if hasattr(original_set, 'indices') else list(range(len(original_set)))
    # Extract images and labels of the original data according to indices
    original_data = [trainset[i][0] for i in original_indices]
    original_targets = [trainset[i][1] for i in original_indices]
    # Set index range of original data for grouping by class
    a, b = 0, len(original_targets)
    # Group original data by class, returning the sample index list of each class
    original_class_idcs = sample_by_class(original_targets, args.num_class, a, b)

    # Process extra dataset similarly
    extra_indices = extra_set.indices if hasattr(extra_set, 'indices') else list(range(len(extra_set)))
    extra_data = [trainset[i][0] for i in extra_indices]
    extra_targets = [trainset[i][1] for i in extra_indices]

    # Recombine full training data for later dynamic allocation
    train_data = original_data + extra_data
    train_targets = original_targets + extra_targets

    # Decide data distribution strategy according to parameters
    if args.iid:
        # IID distribution: data is evenly distributed among clients, each client has samples of all classes
        client_idcs = iid_sampling(original_class_idcs, args.num_worker, args.seed)
    elif not args.iid:
        # Non-IID distribution: simulate heterogeneity in real-world data, uneven distribution among clients
        client_idcs = n_iid_sampling(original_class_idcs, len(original_data), args.num_worker, args.seed)
    else:
        print('Data distribution unknown!')

    # If noise simulation is enabled
    if args.noise:
        # Assign original data to clients according to client indices
        original_client_data, original_client_targets, num_data = trainset_split(original_targets, original_data,
                                                                                 client_idcs, args.num_worker)
        print('Original data numbers:', num_data)
        # Add label noise to client data to simulate real-world mislabeling
        noisy_client_targets, noise_level = data_noisifying(args, original_client_targets, num_data)
        print('Original noise levels:', noise_level)

    clients = [Clients(original_client_data[i], noisy_client_targets[i], client_idcs[i]) for i in
               range(args.num_worker)]

    # Parameter initialization
    if args.model == 'CNN1':
        model = models.CNN1()
    elif args.model == 'CNN2':
        model = models.CNN2()
    elif args.model == 'resnet18':
        model = models.resnet18(args.num_class)
    elif args.model == 'resnet34':
        model = models.resnet34(args.num_class)
    elif args.model == 'resnet50':
        model = models.resnet50(args.num_class)
    elif args.model == 'resnet101':
        model = models.resnet101(args.num_class)
    else:
        print('model error')

    if args.criterion == 'CE':
        criterion = torch.nn.CrossEntropyLoss()

    loss_fn = loss_func.cross_entropy()
    global_dict = copy.deepcopy(model.state_dict())
    number_select = int(args.num_worker * args.choosen_fraction)
    list_test_acc = []

    # Federated learning model training
    for t in range(args.R):
        print('=========The {:d} round========='.format(t + 1))

        # Dynamic data allocation computation - core innovation
        # Compute start position of data range to allocate in this round
        a = len(original_targets) + t / args.R * len(extra_targets)
        # Compute end position of data range to allocate in this round
        b = a + 1 / args.R * len(extra_targets)
        # Group current round data by class
        dynamic_class_idcs = sample_by_class(train_targets, args.num_class, int(a), int(b))
        # Randomly assign dynamic data to clients
        dynamic_idcs = random_sampling(dynamic_class_idcs, args.num_worker, args.seed)

        # If noise is enabled, process dynamic data with noise as well
        if args.noise:
            # Assign dynamic data to clients
            dynamic_data, dynamic_targets, dynamic_num = trainset_split(train_targets, train_data, dynamic_idcs,
                                                                        args.num_worker)
            # Add noise to dynamic data by client
            noisy_dynamic_targets, noise_level = data_noisifying(args, dynamic_targets, dynamic_num)

        # Update dynamic data for all clients
        for i in range(args.num_worker):
            # Each client receives new dynamic data and corresponding noisy labels
            clients[i].dynamic_update(dynamic_data[i], noisy_dynamic_targets[i], dynamic_idcs[i])
        # Randomly select clients participating in this round
        selected = np.random.choice(args.num_worker, number_select, replace=False)
        print('Selected clients:', selected)
        # Initialize containers for this round training results
        local_update, datasize, flcs = {}, [], []  # Local updates, data size, quality score
        for i in range(len(selected)):
            # Client performs local training to generate model updates
            clients[selected[i]].train(args, model, loss_fn, device, local_update, selected[i])
            data_num, noise_score = clients[selected[i]].upload()  # Get number of samples and quality score of this client
            datasize.append(data_num)
            flcs.append(noise_score)
            model.load_state_dict(global_dict)
        print('Selected clients datasize:', datasize)

        # If FedAvg aggregation rule is used
        if args.rule == 'fedavg':
            max_flcs, min_flcs = max(flcs), min(flcs)
            normal_flcs = [(s - min_flcs) / (max_flcs - min_flcs) for s in flcs]
            weight = [(datasize[i] * np.exp(-normal_flcs[i])) for i in range(len(datasize))]
            normal_weights = [w / sum(weight) for w in weight]
            print('Aggregate weights:', normal_weights)
            global_dict = FedAvg(selected, normal_weights, global_dict, local_update)
            model.load_state_dict(global_dict)

        global_acc = validate(testloader, model, criterion, device)
        list_test_acc.append(round(global_acc[0], 2))
        print('Test accuracy:{:.2f}%'.format(global_acc[0]))
    print('Average test accuracy:{:.2f}%'.format(sum(sorted([x for x in list_test_acc], reverse=True)[:5]) / 5))
    print('Full test accuracy:', list_test_acc)


if __name__ == '__main__':
    args = args_parser()
    gc.collect()
    set_random_seed(args.seed)
    main(args)

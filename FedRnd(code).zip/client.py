import math
import numpy as np
import random
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from torchvision import transforms
from verify import model_bias, validate
from collections import defaultdict, Counter
from copy import deepcopy
import warnings

warnings.filterwarnings("ignore")


class Clients:
    def __init__(self, traindata, traintargets, trainidcs):
        self.clean_data = torch.empty((0, *traindata[0].shape))
        self.clean_targets = torch.empty(0, dtype=torch.long)
        self.noisy_data = torch.empty((0, *traindata[0].shape))
        self.noisy_targets = torch.empty(0, dtype=torch.long)

        # Temporary buffers for data and labels (including historical + newly arrived data)
        self.tempodata, self.tempotargets = deepcopy(traindata), deepcopy(traintargets)
        # Wrap temporary data as a TensorDataset
        self.trainset = TensorDataset(torch.stack(self.tempodata), torch.as_tensor(self.tempotargets, dtype=torch.long))
        # Initialize local loss thresholds per class
        self.local_threshold = {cls: 0.0 for cls in np.unique(self.tempotargets)}

        # Test
        # self.datasize = len(self.trainset)

    # Append new data during training
    def dynamic_update(self, dynamic_data, noisy_dynamic_targets, dynamic_idcs):
        self.tempodata += dynamic_data

        self.tempotargets = np.concatenate([self.tempotargets, noisy_dynamic_targets])
        # Rebuild temporary dataset for the next round of filtering
        self.temposet = TensorDataset(torch.stack(self.tempodata), torch.as_tensor(self.tempotargets, dtype=torch.long))

    def train(self, args, model, loss_fn, device, local_update, client_idx):
        # — Optimizer selection —
        if args.optimizer == 'SGD':
            model_optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=5e-4)
        elif args.optimizer == 'Adam':
            model_optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-4)
        else:
            model_optimizer = None

        # Switch model to eval mode for inference only; do not update BatchNorm/Dropout
        model = model.to(device).eval()
        # Deep copy global model parameters for subsequent local model bias computation
        global_dict = deepcopy(model.state_dict())

        # ---Step 1: Compute loss thresholds using historical data (traindata) ---
        """
        Adaptive thresholding: run inference on historical local data under the current model,
        collect loss distribution per class (e.g., median and MAD), and dynamically set a
        class-wise criterion for “high-quality” samples.
        """
        # Historical local training data and labels
        traindata = self.trainset.tensors[0].to(device)
        traintargets = self.trainset.tensors[1].to(device)
        with torch.no_grad():
            logits_train = model(traindata)
            # Compute per-sample cross-entropy loss (no reduction) to obtain each sample's loss
            losses_train = F.cross_entropy(logits_train, traintargets, reduction='none')

        class_thresholds = {}
        for c in traintargets.unique():
            mask = (traintargets == c.item())
            if mask.sum() == 0: continue
            losses = losses_train[mask].cpu().numpy()

            # class_thresholds[c] = losses.mean() + losses.std()
            # Compute median and median absolute deviation (MAD) of the class loss
            median = np.median(losses)  # median
            mad = np.median(np.abs(losses - median))  # MAD

            # Threshold = median + 1.4826 * MAD (scaling factor under normality assumption)
            class_thresholds[c.item()] = median + 1.4826 * mad

        # ---Step 2: Filter newly arrived data (tempodata) using the thresholds---
        tempodata = self.temposet.tensors[0].to(device)

        tempotargets = self.temposet.tensors[1].to(device)

        with torch.no_grad():
            logits_tempo = model(tempodata)

            losses_tempo = F.cross_entropy(logits_tempo, tempotargets, reduction='none')

        clean_mask = []
        for i in range(len(tempodata)):
            target = tempotargets[i].item()
            loss = losses_tempo[i].item()
            threshold = class_thresholds.get(target, float('inf'))
            # Merge historical + new data, compute loss; below-threshold → “clean”, above-threshold → “noisy”
            clean_mask.append(loss < threshold)  # below threshold is treated as clean
        clean_mask = torch.tensor(clean_mask, device=device)

        # Accumulate newly separated clean/noisy samples  # Append newly separated clean samples to clean_data/clean_targets
        self.clean_data = torch.cat([self.clean_data, tempodata[clean_mask].cpu()])
        self.clean_targets = torch.cat([self.clean_targets, tempotargets[clean_mask].cpu()])
        # Append noisy samples to noisy_data/noisy_targets
        self.noisy_data = torch.cat([self.noisy_data, tempodata[~clean_mask].cpu()])
        self.noisy_targets = torch.cat([self.noisy_targets, tempotargets[~clean_mask].cpu()])

        # ---Step 3: Compute CLCS based on intra-class compactness and average loss---
        all_targets = torch.cat([traintargets, tempotargets])
        all_losses = torch.cat([losses_train, losses_tempo]).cpu().numpy()
        all_logits = torch.cat([logits_train, logits_tempo]).cpu().numpy()
        # Row-normalize logits to facilitate cosine similarity
        all_logits = all_logits / np.linalg.norm(all_logits, axis=1, keepdims=True)

        # Compute intra-class cosine similarity (compactness) and intra-class mean loss
        self.clcs, valid_classes = 0, 0
        for c in np.unique(all_targets.cpu().numpy()):
            mask = (all_targets.cpu().numpy() == c)  # mask to select samples of the current class
            if np.sum(mask) <= 1:
                continue
            # Intra-class compactness (cosine similarity)
            logits_c = all_logits[mask]
            mu = np.mean(logits_c, axis=0)
            mu = mu / np.linalg.norm(mu)
            cos_sim = np.dot(logits_c, mu)
            avg_compact = 1 - np.mean(cos_sim)
            # Intra-class average loss
            avg_loss = np.mean(all_losses[mask])

            # Compactness-Loss Consistency Score (CLCS)
            self.clcs += avg_loss * avg_compact
            valid_classes += 1
        self.clcs /= valid_classes  # Final CLCS is the mean over valid classes

        # ---step 4: Data augmentation and preparation---
        """
        1) Apply augmentation only to clean data to avoid amplifying the effect of noisy labels.
        2) Re-organize datasets for subsequent local training.
        3) Build multiple loaders to support different training strategies.
        """
        # Augment clean data
        augment_data, augment_targets = [], []
        augmentation = AdvancedAugmentation(augm_num=1)
        # Iterate through all clean samples
        for idx in range(len(self.clean_data)):
            data = self.clean_data[idx]
            target = self.clean_targets[idx]
            augmented_images = augmentation(data)
            for aug_img in augmented_images:
                augment_data.append(aug_img)
                augment_targets.append(target)

        # Reset buffers and merge clean + noisy to build a new training set
        self.tempodata, self.tempotargets = [], np.array([])
        train_data = torch.cat([self.clean_data, self.noisy_data])
        train_targets = torch.cat([self.clean_targets, self.noisy_targets])
        self.trainset = TensorDataset(train_data, train_targets)
        trainloader = DataLoader(self.trainset, batch_size=args.B, shuffle=True, num_workers=4)

        if augment_data:
            # If augmented samples exist, build noisy set, clean set, and the final augmented set
            augme_data, augme_targets = torch.stack(augment_data), torch.stack(augment_targets)
            noisy_set = TensorDataset(self.noisy_data, self.noisy_targets)
            noisyloader = DataLoader(noisy_set, batch_size=args.B, shuffle=True, num_workers=4)
            clean_data = torch.cat([self.clean_data, augme_data])
            clean_targets = torch.cat([self.clean_targets, augme_targets])
            cleanset = TensorDataset(clean_data, clean_targets)
            cleanloader = DataLoader(cleanset, batch_size=args.B, shuffle=True, num_workers=4)
            self.datasize = len(noisy_set) + len(cleanset)
            # Build the final augmented set for training
            train_data = torch.cat([clean_data, self.noisy_data])
            train_targets = torch.cat([clean_targets, self.noisy_targets])
            self.augmeset = TensorDataset(train_data, train_targets)
            trainloader = DataLoader(self.augmeset, batch_size=args.B, shuffle=True, num_workers=4)

        # ---step 5: Local model training---
        model.to(device).train()
        for i in range(args.E):
            for data, label in trainloader:
                data, label = data.to(device), label.to(device)
                if data.size(0) <= 1: continue
                logits = model(data)

                # # LogitClip
                # probs = F.softmax(logits, dim=1).clone()  # compute probability distribution
                # norms = torch.norm(probs, p=args.lp, dim=-1, keepdim=True)  # norm of probabilities
                # logits_clip = torch.div(logits, norms) * args.ts  # normalize and clip logits
                # clip = (norms > args.ts).expand(-1, logits.shape[-1])  # determine which samples to clip
                # logits = torch.where(clip, logits_clip, logits)
                # loss = loss_fn(logits, label)  # compute loss

                # # SCE
                # ce = loss_fn(logits, label)
                # logits1 = F.softmax(logits, dim=1).clone()
                # logits1 = torch.clamp(logits1, min=1e-8, max=1.0)
                # label_one_hot = F.one_hot(label, args.num_class).float().to(logits1.device)
                # label_one_hot = torch.clamp(label_one_hot, min=1e-8, max=1.0)
                # rce = (-1 * torch.sum(logits1 * torch.log(label_one_hot), dim=1)).mean()
                # loss = args.alpha * ce + args.beta * rce

                # # TCE
                # batch_size = len(logits)
                # logits1 = F.softmax(logits, dim=1).clone()
                # logits1 = torch.clamp(logits1, min=1e-8, max=1.0)
                # logits1 = logits1[torch.arange(batch_size), label].unsqueeze(1)
                # matrix = torch.arange(1, args.ts + 1).unsqueeze(0).cuda()
                # loss = (torch.sum((1 - logits1) ** matrix / matrix, dim=1)).mean()

                model_optimizer.zero_grad()
                loss.backward()
                model_optimizer.step()

            # for data, label in cleanloader:
            #     data, label = data.to(device), label.to(device)
            #     if data.size(0) <= 1: continue
            #     logits = model(data)
            #
            #     loss = loss_fn(logits, label)
            #     model_optimizer.zero_grad()
            #     loss.backward()
            #     model_optimizer.step()

            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()  # Clear CUDA cache to avoid memory bloat/leak

        # Upload model bias  # Write the local model bias relative to the global model into local_update
        local_update[str(client_idx)] = model_bias(model, global_dict)

    def upload(self):
        # Return local sample size and CLCS score for server-side client contribution evaluation
        return self.datasize, self.clcs


# Data augmentation strategy
class AdvancedAugmentation:
    def __init__(self, augm_num=1, fillcolor=(128, 128, 128)):
        self.augm_num = augm_num  # Number of augmented versions to generate per sample
        self.fillcolor = fillcolor  # Fill color reserved for operations like cropping

        # Define the mapping of available image transformation operations
        self.operations = {
            "horizontal_flip": lambda img, _: transforms.RandomHorizontalFlip(p=1.0)(img),
            "vertical_flip": lambda img, _: transforms.RandomVerticalFlip(p=1.0)(img),
            "color_jitter": lambda img, magnitude: transforms.ColorJitter(
                brightness=magnitude, contrast=magnitude, saturation=magnitude, hue=0.1
            )(img),
            "random_crop": lambda img, magnitude: transforms.RandomResizedCrop(
                size=(img.shape[1], img.shape[2]),
                scale=(magnitude, 1.0)
            )(img),
            "rotate": lambda img, magnitude: transforms.functional.rotate(img, magnitude),
            "sharpness": lambda img, magnitude: transforms.functional.adjust_sharpness(img, magnitude),
            "contrast": lambda img, magnitude: transforms.functional.adjust_contrast(img, magnitude),
            "shear_x": lambda img, magnitude: transforms.functional.affine(
                img, angle=0, translate=(0, 0), scale=1.0, shear=(magnitude, 0)
            ),
            "shear_y": lambda img, magnitude: transforms.functional.affine(
                img, angle=0, translate=(0, 0), scale=1.0, shear=(0, magnitude)
            ),
            "translate_x": lambda img, magnitude: transforms.functional.affine(
                img, angle=0, translate=(magnitude * img.shape[1], 0), scale=1.0, shear=(0, 0)
            ),
            "translate_y": lambda img, magnitude: transforms.functional.affine(
                img, angle=0, translate=(0, magnitude * img.shape[2]), scale=1.0, shear=(0, 0)
            ), }

        # Define multiple composite augmentation policies and their application probabilities
        self.policies = [
            {"operations": [("horizontal_flip", 0.5), ("rotate", 15)], "prob": 0.5},
            {"operations": [("vertical_flip", 0.5), ("rotate", -15)], "prob": 0.5},
            {"operations": [("horizontal_flip", 0.5), ("vertical_flip", 0.5)], "prob": 0.5},
            {"operations": [("shear_x", 0.3), ("translate_y", 0.1)], "prob": 0.5},
            {"operations": [("shear_y", 0.3), ("translate_x", 0.1)], "prob": 0.5},
            {"operations": [("sharpness", 1.5), ("contrast", 1.2)], "prob": 0.5},
            {"operations": [("random_crop", 0.9), ("contrast", 0.6)], "prob": 0.5},
            {"operations": [("color_jitter", 0.2), ("random_crop", 0.8)], "prob": 0.5},
            {"operations": [("color_jitter", 0.4), ("sharpness", 1.2)], "prob": 0.5}, ]

    def __call__(self, img):
        augmented_images = []
        for _ in range(self.augm_num):
            policy = random.choice(self.policies)  # randomly pick a policy
            if random.random() < policy["prob"]:  # apply the policy with its probability
                for operation_name, magnitude in policy["operations"]:
                    if operation_name in self.operations:
                        img = self.operations[operation_name](img, magnitude)  # apply operation
            augmented_images.append(img)
        return augmented_images

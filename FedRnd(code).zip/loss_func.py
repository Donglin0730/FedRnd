import torch.nn as nn
import torch.nn.functional as F

def cross_entropy():
    def loss_fn(output, target):
            loss_ = F.cross_entropy(output, target)
            return loss_
    return loss_fn

def L1loss( predict, target):
    loss_f = nn.L1Loss(reduction='mean')
    l1_loss = loss_f(predict, target)
    return l1_loss

def L2loss(predict, target):
    loss_f_mse = nn.MSELoss(reduction='mean')
    loss_mse = loss_f_mse(predict, target)
    return loss_mse

def js(p_output, q_output):
    KLDivLoss = nn.KLDivLoss(reduction='mean')
    log_mean_output = ((p_output + q_output) / 2).log()
    return (KLDivLoss(log_mean_output, p_output) + KLDivLoss(log_mean_output, q_output)) / 2

def kl_div(input, target):
    KLDivLoss = nn.KLDivLoss(reduction='mean')
    return KLDivLoss(input,target)
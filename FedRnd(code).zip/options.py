import argparse

def args_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--num_worker', type=int, default=20,
                        help='number of workers {20, 100}')
    parser.add_argument('--choosen_fraction', type=float, default=0.25,
                        help='fraction of clients selected {0.05, 0.25}')
    parser.add_argument('--B', type=int, default=32,
                        help='batch size')
    parser.add_argument('--R', type=int, default=100,
                        help='global rounds {100, 200}')
    parser.add_argument('--W', type=int, default=20,
                        help='global rounds {20, 40}')
    parser.add_argument('--E', type=int, default=1)
    parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--dir_alpha', type=float, default=0.7,
                        help='dirichlet distribution')
    parser.add_argument('--iid', type=bool, default=False,
                        help='data distribution')
    parser.add_argument('--seed', type=int, default=666666,
                        help='random seed')

    # dataset and model setiing
    parser.add_argument('--num_class', type=int, default=10)
    parser.add_argument('--dataset', type=str, default='mnist',
                        help="mnist, fashionmnist, cifar10, cifar100")
    parser.add_argument('--model', type=str, default='CNN1',
                        help="CNN1, CNN2, resnet18, resnet34")

    # training setting
    parser.add_argument('--criterion', type=str, default='CE')
    parser.add_argument('--rule', type=str, default='fedavg')
    parser.add_argument('--optimizer', type=str, default='SGD')
    parser.add_argument('--ts', type=float, default=0.8)
    parser.add_argument('--lp', type=float, default=2.0)
    parser.add_argument('--alpha', type=float, default=0.1)
    parser.add_argument('--beta', type=float, default=2.0)

    # noise setting
    parser.add_argument('--noise', type=bool, default=False)
    parser.add_argument('--noise_type', type=str, default='symmetric')
    parser.add_argument('--noise_ratio', type=float, default=0.5,
                        help = 'noisy clients selection ratio')
    parser.add_argument('--noise_lowbound', type=float, default=0.6,
                        help='noise lower bound {0.2, 0.4, 0.6}')
    return parser.parse_args()
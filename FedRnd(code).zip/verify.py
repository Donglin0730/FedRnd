import torch
from copy import deepcopy
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

def model_bias(model, model_dict):
    local_dict = deepcopy(model.state_dict())
    update = dict()
    for k, v in model_dict.items():
        v = v.to(torch.device('cpu'))
        local_dict[k] = local_dict[k].to(torch.device('cpu'))
        update[k] = local_dict[k] - v
    return update

def validate(loader, model, criterion, device):
    total_loss = 0.0
    total = 0
    accuracy = 0.0
    precision = 0.0
    recall = 0.0
    f1 = 0.0

    model.eval()
    model.to(device)

    with torch.no_grad():
        for idx, (inputs, targets) in enumerate(loader):
            inputs = inputs.to(device)
            targets = targets.to(device).long()
            outputs = model(inputs)
            preds = outputs.argmax(dim=1)

            total_loss += criterion(outputs, targets).item()
            accuracy += accuracy_score(targets.cpu(), preds.cpu())
            precision += precision_score(targets.cpu(), preds.cpu(), average='macro')
            recall += recall_score(targets.cpu(), preds.cpu(), average='macro')
            f1 += f1_score(targets.cpu(), preds.cpu(), average='macro')
            total += len(inputs)

    num_batches = idx + 1
    if num_batches > 0:
        acc = accuracy / num_batches * 100
        precision = precision / num_batches * 100
        recall = recall / num_batches * 100
        f1 = f1 / num_batches * 100
        avg_loss = total_loss / num_batches
    else:
        acc = precision = recall = f1 = avg_loss = 0.0

    return acc, precision, recall, f1, avg_loss